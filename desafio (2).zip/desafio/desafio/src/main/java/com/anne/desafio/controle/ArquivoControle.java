package com.anne.desafio.controle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.anne.desafio.modelo.entidade.Arquivo;
import com.anne.desafio.servico.ArquivoServico;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class ArquivoControle {
    @GetMapping("/")
    public String rota (){
        return "teste de desafio";
    }

    @Autowired
    private ArquivoServico arquivoServico;
    @GetMapping("/arquivo")
    public Iterable<Arquivo>listar(){
        return arquivoServico.listar();
    }

    @PostMapping("/arquivo")
    public ResponseEntity<?> salvar(@RequestBody Arquivo arquivo){
        return arquivoServico.salvar(arquivo, "Salvar");

    }
      @PutMapping("/arquivo/{id}")
    public ResponseEntity<?> update(@RequestBody Arquivo arquivo) {
        return arquivoServico.salvar(arquivo, "Atualizar");
    }

    @DeleteMapping ("/arquivo/{id}")
    public ResponseEntity<?> remover(@PathVariable Long id) {
        return arquivoServico.remover(id);
    
    }
}

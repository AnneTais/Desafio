package com.anne.desafio.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.anne.desafio.modelo.entidade.Arquivo;

@Repository
public interface ArquivoRepositorio extends CrudRepository<Arquivo,Long>{
    
}

package com.anne.desafio.servico;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.anne.desafio.modelo.UserModeloResponse;
import com.anne.desafio.modelo.entidade.Arquivo;
import com.anne.desafio.repository.ArquivoRepositorio;

@Service
public class ArquivoServico {
    @Autowired
    private ArquivoRepositorio arquivorRepositorio;

    public Iterable<Arquivo> listar(){
        return arquivorRepositorio.findAll();
    }

    @Autowired
    private UserModeloResponse  userModeloResponse;

    public ResponseEntity<?> salvar(Arquivo arquivo,String acao){
        if (arquivo.getDescricao().equals("")){
            userModeloResponse.setMessage("Descrição inválida");
            return new ResponseEntity<UserModeloResponse>(userModeloResponse ,HttpStatus.BAD_REQUEST);
        } else {
            if (acao.equals("Salvar")){
                return new ResponseEntity<Arquivo>(arquivorRepositorio.save(arquivo) ,HttpStatus.CREATED);    
            } else{
                return new ResponseEntity<Arquivo>(arquivorRepositorio.save(arquivo) ,HttpStatus.OK);
            }
        }
    }

    public ResponseEntity<?> remover (Long id) {
        arquivorRepositorio.deleteById(id);
        userModeloResponse.setMessage("Informação removida com sucessso");
        return new ResponseEntity<UserModeloResponse>(userModeloResponse ,HttpStatus.OK);
    }

}
